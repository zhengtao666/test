package org.kfc.action.beanCase;


import org.apache.struts.actions.DispatchAction;

import org.kfc.cart.Cart;
import org.kfc.service.AdminService;
import org.kfc.service.ComplainService;
import org.kfc.service.GradeService;
import org.kfc.service.LinksService;
import org.kfc.service.MemberService;
import org.kfc.service.NewsClassService;
import org.kfc.service.NewsService;
import org.kfc.service.OrderItemService;
import org.kfc.service.OrdersService;
import org.kfc.service.PlayMessageService;
import org.kfc.service.ProductService;
import org.kfc.service.PubService;
import org.kfc.service.SortService;
import org.kfc.service.UserSayService;
import org.kfc.template.pagination.KFCHibernateTemplatePage;


public class KFCDispatchAction extends DispatchAction {

	protected AdminService adminService;
	protected ComplainService complainService;
	protected GradeService gradeService;
	protected LinksService linksService;
	protected MemberService memberService;
	protected NewsService newsService;
	protected NewsClassService newsClassService;
	protected OrderItemService orderItemService;
	protected OrdersService ordersService;
	protected PlayMessageService playMessageService;
	protected ProductService productService;
	protected PubService pubService;
	protected SortService sortService;
	protected UserSayService userSayService;
	
	protected Cart cart;
	
	protected KFCHibernateTemplatePage kfcTemplatePage;
	
	public AdminService getAdminService() {
		return adminService;
	}

	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}

	public ComplainService getComplainService() {
		return complainService;
	}

	public void setComplainService(ComplainService complainService) {
		this.complainService = complainService;
	}

	public GradeService getGradeService() {
		return gradeService;
	}

	public void setGradeService(GradeService gradeService) {
		this.gradeService = gradeService;
	}

	public LinksService getLinksService() {
		return linksService;
	}

	public void setLinksService(LinksService linksService) {
		this.linksService = linksService;
	}

	public MemberService getMemberService() {
		return memberService;
	}

	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}

	public NewsService getNewsService() {
		return newsService;
	}

	public void setNewsService(NewsService newsService) {
		this.newsService = newsService;
	}

	public NewsClassService getNewsClassService() {
		return newsClassService;
	}

	public void setNewsClassService(NewsClassService newsClassService) {
		this.newsClassService = newsClassService;
	}

	public OrderItemService getOrderItemService() {
		return orderItemService;
	}

	public void setOrderItemService(OrderItemService orderItemService) {
		this.orderItemService = orderItemService;
	}

	public OrdersService getOrdersService() {
		return ordersService;
	}

	public void setOrdersService(OrdersService ordersService) {
		this.ordersService = ordersService;
	}

	public PlayMessageService getPlayMessageService() {
		return playMessageService;
	}

	public void setPlayMessageService(PlayMessageService playMessageService) {
		this.playMessageService = playMessageService;
	}

	public ProductService getProductService() {
		return productService;
	}

	public void setProductService(ProductService productService) {
		this.productService = productService;
	}

	public PubService getPubService() {
		return pubService;
	}

	public void setPubService(PubService pubService) {
		this.pubService = pubService;
	}

	public SortService getSortService() {
		return sortService;
	}

	public void setSortService(SortService sortService) {
		this.sortService = sortService;
	}

	public UserSayService getUserSayService() {
		return userSayService;
	}

	public void setUserSayService(UserSayService userSayService) {
		this.userSayService = userSayService;
	}

	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}
	

	public KFCHibernateTemplatePage getKfcTemplatePage() {
		return kfcTemplatePage;
	}

	public void setKfcTemplatePage(KFCHibernateTemplatePage kfcTemplatePage) {
		this.kfcTemplatePage = kfcTemplatePage;
	}


}
