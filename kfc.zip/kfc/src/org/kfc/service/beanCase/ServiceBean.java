package org.kfc.service.beanCase;

import org.dataFormat.KFCSimpleDateFormat;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.kfc.dao.AdminDao;
import org.kfc.dao.ComplainDao;
import org.kfc.dao.GradeDao;
import org.kfc.dao.LinksDao;
import org.kfc.dao.MemberDao;
import org.kfc.dao.NewsClassDao;
import org.kfc.dao.NewsDao;
import org.kfc.dao.OrderItemDao;
import org.kfc.dao.OrdersDao;
import org.kfc.dao.PlayMessageDao;
import org.kfc.dao.ProductDao;
import org.kfc.dao.PubDao;
import org.kfc.dao.SortDao;
import org.kfc.dao.UserSayDao;
import org.kfc.model.Admin;
import org.kfc.model.Complain;
import org.kfc.model.Grade;
import org.kfc.model.Links;
import org.kfc.model.Member;
import org.kfc.model.News;
import org.kfc.model.Newsclass;
import org.kfc.model.Orderitem;
import org.kfc.model.Orders;
import org.kfc.model.Playmessage;
import org.kfc.model.Product;
import org.kfc.model.Pub;
import org.kfc.model.Sort;
import org.kfc.model.Usersay;

public class ServiceBean {

    protected KFCSimpleDateFormat sdf;
    protected Session session;
    protected SessionFactory sessionFactory;
    protected Transaction tx;
    
	protected AdminDao adminDao;
    protected ComplainDao complainDao;
	protected GradeDao gradeDao;
	protected LinksDao linksDao;
	protected MemberDao memberDao;
	protected NewsClassDao newsClassDao;
	protected NewsDao newsDao;
	protected OrderItemDao orderItemDao;
    protected OrdersDao ordersDao;
    protected PlayMessageDao playMessageDao;
    protected ProductDao productDao;
    protected PubDao pubDao;
	protected SortDao sortDao;
	protected UserSayDao userSayDao;
	
    protected Admin admin;
    protected Complain complain;
    protected Grade grade;
	protected Links links;
	protected Member member;
	protected Newsclass newsClass;
	protected News news;
	protected Orders orders;
	protected Orderitem orderItem;
	protected Playmessage playMessage;
	protected Product product;
	protected Pub pub;
	protected Sort sort;
	protected Usersay userSay;
	
	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	public AdminDao getAdminDao() {
		return adminDao;
	}
	
	public void setAdminDao(AdminDao adminDao) {
		this.adminDao = adminDao;
	}

	public KFCSimpleDateFormat getSdf() {
		return sdf;
	}

	public void setSdf(KFCSimpleDateFormat sdf) {
		this.sdf = sdf;
	}

	public ComplainDao getComplainDao() {
		return complainDao;
	}

	public void setComplainDao(ComplainDao complainDao) {
		this.complainDao = complainDao;
	}

	public OrdersDao getOrdersDao() {
		return ordersDao;
	}

	public void setOrdersDao(OrdersDao ordersDao) {
		this.ordersDao = ordersDao;
	}

	public Complain getComplain() {
		return complain;
	}

	public void setComplain(Complain complain) {
		this.complain = complain;
	}

	public GradeDao getGradeDao() {
		return gradeDao;
	}

	public void setGradeDao(GradeDao gradeDao) {
		this.gradeDao = gradeDao;
	}

	public LinksDao getLinksDao() {
		return linksDao;
	}

	public void setLinksDao(LinksDao linksDao) {
		this.linksDao = linksDao;
	}

	public Links getLinks() {
		return links;
	}

	public void setLinks(Links links) {
		this.links = links;
	}

	public MemberDao getMemberDao() {
		return memberDao;
	}

	public void setMemberDao(MemberDao memberDao) {
		this.memberDao = memberDao;
	}

	public NewsClassDao getNewsClassDao() {
		return newsClassDao;
	}

	public void setNewsClassDao(NewsClassDao newsClassDao) {
		this.newsClassDao = newsClassDao;
	}

	public NewsDao getNewsDao() {
		return newsDao;
	}

	public void setNewsDao(NewsDao newsDao) {
		this.newsDao = newsDao;
	}

	public News getNews() {
		return news;
	}

	public void setNews(News news) {
		this.news = news;
	}

	public OrderItemDao getOrderItemDao() {
		return orderItemDao;
	}

	public void setOrderItemDao(OrderItemDao orderItemDao) {
		this.orderItemDao = orderItemDao;
	}

	public Orders getOrders() {
		return orders;
	}

	public void setOrders(Orders orders) {
		this.orders = orders;
	}

	public PlayMessageDao getPlayMessageDao() {
		return playMessageDao;
	}

	public void setPlayMessageDao(PlayMessageDao playMessageDao) {
		this.playMessageDao = playMessageDao;
	}

	public Playmessage getPlayMessage() {
		return playMessage;
	}

	public void setPlayMessage(Playmessage playMessage) {
		this.playMessage = playMessage;
	}

	public PubDao getPubDao() {
		return pubDao;
	}

	public void setPubDao(PubDao pubDao) {
		this.pubDao = pubDao;
	}

	public SortDao getSortDao() {
		return sortDao;
	}

	public void setSortDao(SortDao sortDao) {
		this.sortDao = sortDao;
	}

	public UserSayDao getUserSayDao() {
		return userSayDao;
	}

	public void setUserSayDao(UserSayDao userSayDao) {
		this.userSayDao = userSayDao;
	}

	public ProductDao getProductDao() {
		return productDao;
	}

	public void setProductDao(ProductDao productDao) {
		this.productDao = productDao;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Pub getPub() {
		return pub;
	}

	public void setPub(Pub pub) {
		this.pub = pub;
	}

	public Sort getSort() {
		return sort;
	}

	public void setSort(Sort sort) {
		this.sort = sort;
	}

	public Usersay getUserSay() {
		return userSay;
	}

	public void setUserSay(Usersay userSay) {
		this.userSay = userSay;
	}

	public Grade getGrade() {
		return grade;
	}

	public void setGrade(Grade grade) {
		this.grade = grade;
	}

	public Newsclass getNewsClass() {
		return newsClass;
	}

	public void setNewsClass(Newsclass newsClass) {
		this.newsClass = newsClass;
	}

	public Orderitem getOrderItem() {
		return orderItem;
	}

	public void setOrderItem(Orderitem orderItem) {
		this.orderItem = orderItem;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
}
