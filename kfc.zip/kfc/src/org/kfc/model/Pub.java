package org.kfc.model;

/**
 * Pub entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Pub implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer pubId;
	private Integer adminId;
	private String title;
	private String msg;
	private String dateTime;

	// Constructors

	/** default constructor */
	public Pub() {
	}

	/** full constructor */
	public Pub(Integer adminId, String title, String msg, String dateTime) {
		this.adminId = adminId;
		this.title = title;
		this.msg = msg;
		this.dateTime = dateTime;
	}

	// Property accessors

	public Integer getPubId() {
		return this.pubId;
	}

	public void setPubId(Integer pubId) {
		this.pubId = pubId;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getMsg() {
		return this.msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getDateTime() {
		return this.dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public Integer getAdminId() {
		return adminId;
	}

	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}

}