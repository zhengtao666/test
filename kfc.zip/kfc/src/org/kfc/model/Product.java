package org.kfc.model;

import java.util.HashSet;
import java.util.Set;

/**
 * Product entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Product implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer pid;
	private Integer sortId;
	private String name;
	private Double memberPrice;
	private String abstract_;
	private String detail;
	private String proFunction;
	private String picture;
	private Double vipPrice;
	private Double marketPrice;
	private String company;
	private Integer bpromoted;
	private Integer sale;
	private Set<Orderitem> orderitems = new HashSet<Orderitem>(0);
	private Set<Usersay> usersaies = new HashSet<Usersay>(0);

	// Constructors

	/** default constructor */
	public Product() {
	}
	/** full constructor */
	public Product(Integer sortId, String name, Double memberPrice,
			String abstract_, String detail, String proFunction,
			String picture, Double vipPrice, Double marketPrice,
			String company,Integer bpromoted, Integer sale, Set<Orderitem> orderitems,
			Set<Usersay> usersaies) {
		this.sortId = sortId;
		this.name = name;
		this.memberPrice = memberPrice;
		this.abstract_ = abstract_;
		this.detail = detail;
		this.proFunction = proFunction;
		this.picture = picture;
		this.vipPrice = vipPrice;
		this.marketPrice = marketPrice;
		this.company = company;
		this.bpromoted = bpromoted;
		this.sale = sale;
		this.orderitems = orderitems;
		this.usersaies = usersaies;
	}

	// Property accessors

	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getMemberPrice() {
		return this.memberPrice;
	}

	public void setMemberPrice(Double memberPrice) {
		this.memberPrice = memberPrice;
	}

	public String getAbstract_() {
		return this.abstract_;
	}

	public void setAbstract_(String abstract_) {
		this.abstract_ = abstract_;
	}

	public String getDetail() {
		return this.detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	public String getProFunction() {
		return this.proFunction;
	}

	public void setProFunction(String proFunction) {
		this.proFunction = proFunction;
	}

	public String getPicture() {
		return this.picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public Double getVipPrice() {
		return this.vipPrice;
	}

	public void setVipPrice(Double vipPrice) {
		this.vipPrice = vipPrice;
	}

	public Double getMarketPrice() {
		return this.marketPrice;
	}

	public void setMarketPrice(Double marketPrice) {
		this.marketPrice = marketPrice;
	}

	public String getCompany() {
		return this.company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public Integer getBpromoted() {
		return this.bpromoted;
	}

	public void setBpromoted(Integer bpromoted) {
		this.bpromoted = bpromoted;
	}

	public Integer getSale() {
		return this.sale;
	}

	public void setSale(Integer sale) {
		this.sale = sale;
	}

	public Set<Orderitem> getOrderitems() {
		return this.orderitems;
	}

	public void setOrderitems(Set<Orderitem> orderitems) {
		this.orderitems = orderitems;
	}

	public Set<Usersay> getUsersaies() {
		return this.usersaies;
	}

	public void setUsersaies(Set<Usersay> usersaies) {
		this.usersaies = usersaies;
	}
	public Integer getSortId() {
		return sortId;
	}
	public void setSortId(Integer sortId) {
		this.sortId = sortId;
	}

}