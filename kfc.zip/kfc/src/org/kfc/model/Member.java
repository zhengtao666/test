package org.kfc.model;

import java.util.HashSet;
import java.util.Set;

/**
 * Member entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Member implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Fields

	private Integer userId;
	private Integer codeId;
	private String userName;
	private String userPass;
	private String userMail;
	private String userAdds;
	private String userTel;
	private String userRegtime;
	private String userRegip;
	private String userLastTime;
	private String userLastIp;
	private Double userBuyMoney;
	private String userPostCode;
	private String userNamec;
	private String userType;
	private Set<Usersay> usersaies = new HashSet<Usersay>(0);
	private Set<Orderitem> orderitems = new HashSet<Orderitem>(0);

	// Constructors

	/** default constructor */
	public Member() {
	}

	/** full constructor */
	public Member(Integer codeId, String userName, String userPass,
			String userMail, String userAdds, String userTel, String userRegtime,
			String userRegip, String userLastTime, String userLastIp,
			Double userBuyMoney, String userPostCode, String userNamec,
			String userType, Set<Usersay> usersaies, Set<Orderitem> orderitems) {
		this.codeId = codeId;
		this.userName = userName;
		this.userPass = userPass;
		this.userMail = userMail;
		this.userAdds = userAdds;
		this.userTel = userTel;
		this.userRegtime = userRegtime;
		this.userRegip = userRegip;
		this.userLastTime = userLastTime;
		this.userLastIp = userLastIp;
		this.userBuyMoney = userBuyMoney;
		this.userPostCode = userPostCode;
		this.userNamec = userNamec;
		this.userType = userType;
		this.usersaies = usersaies;
		this.orderitems = orderitems;
	}

	// Property accessors

	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return this.userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPass() {
		return this.userPass;
	}

	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}

	public String getUserMail() {
		return this.userMail;
	}

	public void setUserMail(String userMail) {
		this.userMail = userMail;
	}

	public String getUserAdds() {
		return this.userAdds;
	}

	public void setUserAdds(String userAdds) {
		this.userAdds = userAdds;
	}

	public String getUserTel() {
		return this.userTel;
	}

	public void setUserTel(String userTel) {
		this.userTel = userTel;
	}

	public String getUserRegip() {
		return this.userRegip;
	}

	public void setUserRegip(String userRegip) {
		this.userRegip = userRegip;
	}


	public String getUserLastIp() {
		return this.userLastIp;
	}

	public void setUserLastIp(String userLastIp) {
		this.userLastIp = userLastIp;
	}

	public String getUserPostCode() {
		return this.userPostCode;
	}

	public void setUserPostCode(String userPostCode) {
		this.userPostCode = userPostCode;
	}

	public String getUserNamec() {
		return this.userNamec;
	}

	public void setUserNamec(String userNamec) {
		this.userNamec = userNamec;
	}

	public String getUserType() {
		return this.userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public Set<Usersay> getUsersaies() {
		return this.usersaies;
	}

	public void setUsersaies(Set<Usersay> usersaies) {
		this.usersaies = usersaies;
	}

	public Set<Orderitem> getOrderitems() {
		return this.orderitems;
	}

	public void setOrderitems(Set<Orderitem> orderitems) {
		this.orderitems = orderitems;
	}

	public String getUserRegtime() {
		return userRegtime;
	}

	public void setUserRegtime(String userRegtime) {
		this.userRegtime = userRegtime;
	}

	public String getUserLastTime() {
		return userLastTime;
	}

	public void setUserLastTime(String userLastTime) {
		this.userLastTime = userLastTime;
	}

	public Double getUserBuyMoney() {
		return userBuyMoney;
	}

	public void setUserBuyMoney(Double userBuyMoney) {
		this.userBuyMoney = userBuyMoney;
	}

	public Integer getCodeId() {
		return codeId;
	}

	public void setCodeId(Integer codeId) {
		this.codeId = codeId;
	}

}