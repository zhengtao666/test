package org.kfc.model;

/**
 * Usersay entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Usersay implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer sayId;
	private Integer userId;
	private Integer pid;
	private String say;
	private Integer level;

	// Constructors

	/** default constructor */
	public Usersay() {
	}

	/** full constructor */
	public Usersay(Integer userId, Integer pid, String say, Integer level) {
		this.userId = userId;
		this.pid = pid;
		this.say = say;
		this.level = level;
	}

	// Property accessors

	public Integer getSayId() {
		return this.sayId;
	}

	public void setSayId(Integer sayId) {
		this.sayId = sayId;
	}

	public String getSay() {
		return this.say;
	}

	public void setSay(String say) {
		this.say = say;
	}

	public Integer getLevel() {
		return this.level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getPid() {
		return pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

}