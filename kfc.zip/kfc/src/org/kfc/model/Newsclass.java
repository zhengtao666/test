package org.kfc.model;

import java.util.HashSet;
import java.util.Set;

/**
 * Newsclass entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Newsclass implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 380115900090270601L;
	// Fields

	/**
	 * 
	 */
	private Integer newsClassId;
	private String newsClassName;
	private Set<News> newses = new HashSet<News>(0);

	// Constructors

	/** default constructor */
	public Newsclass() {
	}

	/** full constructor */
	public Newsclass(String newsClassName, Set<News> newses) {
		this.newsClassName = newsClassName;
		this.newses = newses;
	}

	// Property accessors

	public Integer getNewsClassId() {
		return this.newsClassId;
	}

	public void setNewsClassId(Integer newsClassId) {
		this.newsClassId = newsClassId;
	}

	public String getNewsClassName() {
		return this.newsClassName;
	}

	public void setNewsClassName(String newsClassName) {
		this.newsClassName = newsClassName;
	}

	public Set<News> getNewses() {
		return this.newses;
	}

	public void setNewses(Set<News> newses) {
		this.newses = newses;
	}

}