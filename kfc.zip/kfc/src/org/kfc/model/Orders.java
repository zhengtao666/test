package org.kfc.model;

import java.util.HashSet;
import java.util.Set;

/**
 * Orders entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Orders implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Fields

	private Integer orderId;
	private String name;
	private String telephone;
	private String address;
	private String email;
	private boolean bchecked;
	private String postCode;
	private String payment;
	private String memo;
	private String orderDatetime;
	private Set<Complain> complains = new HashSet<Complain>(0);
	private Set<Orderitem> orderitems = new HashSet<Orderitem>(0);
	private Set<Playmessage> playmessages = new HashSet<Playmessage>(0);

	// Constructors

	/** default constructor */
	public Orders() {
	}

	/** full constructor */
	public Orders(String name, String telephone, String address, String email,
			boolean bchecked, String postCode, String payment, String memo,
			String orderDatetime, Set<Complain> complains, Set<Orderitem> orderitems, Set<Playmessage> playmessages) {
		this.name = name;
		this.telephone = telephone;
		this.address = address;
		this.email = email;
		this.bchecked = bchecked;
		this.postCode = postCode;
		this.payment = payment;
		this.memo = memo;
		this.orderDatetime = orderDatetime;
		this.complains = complains;
		this.orderitems = orderitems;
		this.playmessages = playmessages;
	}

	// Property accessors

	public Integer getOrderId() {
		return this.orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTelephone() {
		return this.telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPostCode() {
		return this.postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getPayment() {
		return this.payment;
	}

	public void setPayment(String payment) {
		this.payment = payment;
	}

	public String getMemo() {
		return this.memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public Set<Complain> getComplains() {
		return this.complains;
	}

	public void setComplains(Set<Complain> complains) {
		this.complains = complains;
	}

	public Set<Orderitem> getOrderitems() {
		return this.orderitems;
	}

	public void setOrderitems(Set<Orderitem> orderitems) {
		this.orderitems = orderitems;
	}

	public Set<Playmessage> getPlaymessages() {
		return this.playmessages;
	}

	public void setPlaymessages(Set<Playmessage> playmessages) {
		this.playmessages = playmessages;
	}

	public boolean isBchecked() {
		return bchecked;
	}

	public void setBchecked(boolean bchecked) {
		this.bchecked = bchecked;
	}

	public String getOrderDatetime() {
		return orderDatetime;
	}

	public void setOrderDatetime(String orderDatetime) {
		this.orderDatetime = orderDatetime;
	}

}