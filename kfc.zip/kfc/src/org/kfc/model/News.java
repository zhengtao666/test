package org.kfc.model;

/**
 * News entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class News implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer newsId;
	private Integer newsClassId;
	private String newsTitle;
	private String newsContent;
	private String newsDate;

	// Constructors

	/** default constructor */
	public News() {
	}

	/** full constructor */
	public News(Integer newsClassId, String newsTitle, String newsContent,
			String newsDate) {
		this.newsClassId =newsClassId;
		this.newsTitle = newsTitle;
		this.newsContent = newsContent;
		this.newsDate = newsDate;
	}

	// Property accessors

	public Integer getNewsId() {
		return this.newsId;
	}

	public void setNewsId(Integer newsId) {
		this.newsId = newsId;
	}

	public String getNewsTitle() {
		return this.newsTitle;
	}

	public void setNewsTitle(String newsTitle) {
		this.newsTitle = newsTitle;
	}

	public String getNewsContent() {
		return this.newsContent;
	}

	public void setNewsContent(String newsContent) {
		this.newsContent = newsContent;
	}

	public String getNewsDate() {
		return this.newsDate;
	}

	public void setNewsDate(String newsDate) {
		this.newsDate = newsDate;
	}

	public Integer getNewsClassId() {
		return newsClassId;
	}

	public void setNewsClassId(Integer newsClassId) {
		this.newsClassId = newsClassId;
	}

}