package org.kfc.model;

import java.util.HashSet;
import java.util.Set;

/**
 * Admin entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Admin implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer adminId;
	private String adminName;
	private String adminPass;
	private Integer adminType;
	private Set<Pub> pubs = new HashSet<Pub>(0);
	private Set<Playmessage> playmessages = new HashSet<Playmessage>(0);

	// Constructors

	/** default constructor */
	public Admin() {
	}

	/** full constructor */
	public Admin(String adminName, String adminPass, Integer adminType,
			Set<Pub> pubs, Set<Playmessage> playmessages) {
		this.adminName = adminName;
		this.adminPass = adminPass;
		this.adminType = adminType;
		this.pubs = pubs;
		this.playmessages = playmessages;
	}

	// Property accessors

	public Integer getAdminId() {
		return this.adminId;
	}

	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}

	public String getAdminName() {
		return this.adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getAdminPass() {
		return this.adminPass;
	}

	public void setAdminPass(String adminPass) {
		this.adminPass = adminPass;
	}

	public Integer getAdminType() {
		return this.adminType;
	}

	public void setAdminType(Integer adminType) {
		this.adminType = adminType;
	}

	public Set<Pub> getPubs() {
		return this.pubs;
	}

	public void setPubs(Set<Pub> pubs) {
		this.pubs = pubs;
	}

	public Set<Playmessage> getPlaymessages() {
		return this.playmessages;
	}

	public void setPlaymessages(Set<Playmessage> playmessages) {
		this.playmessages = playmessages;
	}

}