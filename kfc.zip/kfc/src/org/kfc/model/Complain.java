package org.kfc.model;

/**
 * Complain entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Complain implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer complainId;
	private Integer orderId;
	private String userName;
	private String complainDate;
	private String content;

	// Constructors

	/** default constructor */
	public Complain() {
	}

	/** full constructor */
	public Complain(Integer orderId, String userName, String complainDate,
			String content) {
		this.orderId = orderId;
		this.userName = userName;
		this.complainDate = complainDate;
		this.content = content;
	}

	// Property accessors

	public Integer getComplainId() {
		return this.complainId;
	}

	public void setComplainId(Integer complainId) {
		this.complainId = complainId;
	}

	public String getUserName() {
		return this.userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getComplainDate() {
		return this.complainDate;
	}

	public void setComplainDate(String complainDate) {
		this.complainDate = complainDate;
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

}