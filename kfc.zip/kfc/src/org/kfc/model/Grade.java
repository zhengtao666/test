package org.kfc.model;

import java.util.HashSet;
import java.util.Set;

/**
 * Grade entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Grade implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer codeId;
	private Integer code;
	private String grade;
	private String codePic;
	private Set<Member> members = new HashSet<Member>(0);

	// Constructors

	/** default constructor */
	public Grade() {
	}

	/** full constructor */
	public Grade(Integer code, String grade, String codePic, Set<Member> members) {
		this.code = code;
		this.grade = grade;
		this.codePic = codePic;
		this.members = members;
	}

	// Property accessors

	public Integer getCodeId() {
		return this.codeId;
	}

	public void setCodeId(Integer codeId) {
		this.codeId = codeId;
	}

	public Integer getCode() {
		return this.code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	public String getGrade() {
		return this.grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getCodePic() {
		return this.codePic;
	}

	public void setCodePic(String codePic) {
		this.codePic = codePic;
	}

	public Set<Member> getMembers() {
		return this.members;
	}

	public void setMembers(Set<Member> members) {
		this.members = members;
	}

}