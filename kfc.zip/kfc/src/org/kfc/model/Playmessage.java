package org.kfc.model;

/**
 * Playmessage entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Playmessage implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer playId;
	private Integer orderId;
	private Integer adminId;
	private String playMsg;
	private String playDatetime;

	// Constructors

	/** default constructor */
	public Playmessage() {
	}

	/** full constructor */
	public Playmessage(Integer orderId,Integer adminId, String playMsg,
			String playDatetime) {
		this.orderId = orderId;
		this.adminId = adminId;
		this.playMsg = playMsg;
		this.playDatetime = playDatetime;
	}

	// Property accessors

	public Integer getPlayId() {
		return this.playId;
	}

	public void setPlayId(Integer playId) {
		this.playId = playId;
	}

	public String getPlayMsg() {
		return this.playMsg;
	}

	public void setPlayMsg(String playMsg) {
		this.playMsg = playMsg;
	}

	public String getPlayDatetime() {
		return this.playDatetime;
	}

	public void setPlayDatetime(String playDatetime) {
		this.playDatetime = playDatetime;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getAdminId() {
		return adminId;
	}

	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}

}