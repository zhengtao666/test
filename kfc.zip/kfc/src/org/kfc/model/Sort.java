package org.kfc.model;

import java.util.HashSet;
import java.util.Set;

/**
 * Sort entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Sort implements java.io.Serializable {

	// Fields

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer sortId;
	private String sortName;
	private String particularSort;
	private Set<Product> products = new HashSet<Product>(0);

	// Constructors

	/** default constructor */
	public Sort() {
	}

	/** full constructor */
	public Sort(String sortName,String particularSort,Set<Product> products) {
		this.particularSort=particularSort;
		this.sortName = sortName;
		this.products = products;
	}

	// Property accessors

	public Integer getSortId() {
		return this.sortId;
	}

	public void setSortId(Integer sortId) {
		this.sortId = sortId;
	}

	public String getSortName() {
		return this.sortName;
	}

	public void setSortName(String sortName) {
		this.sortName = sortName;
	}

	public Set<Product> getProducts() {
		return this.products;
	}

	public void setProducts(Set<Product> products) {
		this.products = products;
	}

	public String getParticularSort() {
		return particularSort;
	}

	public void setParticularSort(String particularSort) {
		this.particularSort = particularSort;
	}

}