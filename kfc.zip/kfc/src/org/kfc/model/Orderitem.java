package org.kfc.model;

/**
 * Orderitem entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Orderitem implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Fields

	/**
	 * 
	 */
	private Integer itemId;
	private Integer orderId;
	private Integer userId;
	private Integer pid;
	private Integer count;
	private Double price;

	// Constructors

	/** default constructor */
	public Orderitem() {
	}

	/** full constructor */
	public Orderitem(Integer orderId, Integer userId, Integer pid,
			Integer count, Double price) {
		this.orderId = orderId;
		this.userId = userId;
		this.pid = pid;
		this.count = count;
		this.price = price;
	}

	// Property accessors

	public Integer getItemId() {
		return this.itemId;
	}

	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}

	public Double getPrice() {
		return this.price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}
	public double getSum(){
		return this.price*this.count;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getPid() {
		return pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

}