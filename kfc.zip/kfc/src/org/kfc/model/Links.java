package org.kfc.model;

/**
 * Links entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Links implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Fields

	/**
	 * 
	 */
	private Integer adId;
	private String url;
	private String wordLink;
	private String content;
	private Integer lien;

	// Constructors

	/** default constructor */
	public Links() {
	}

	/** full constructor */
	public Links(String url, String wordLink, String content, Integer lien) {
		this.url = url;
		this.wordLink = wordLink;
		this.content = content;
		this.lien = lien;
	}

	// Property accessors

	public Integer getAdId() {
		return this.adId;
	}

	public void setAdId(Integer adId) {
		this.adId = adId;
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Integer getLien() {
		return this.lien;
	}

	public void setLien(Integer lien) {
		this.lien = lien;
	}

	public String getWordLink() {
		return wordLink;
	}

	public void setWordLink(String wordLink) {
		this.wordLink = wordLink;
	}

}