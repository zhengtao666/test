package org.kfc.template;

import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class KFCHibernateTemplate extends HibernateTemplate{
   private  SessionFactory sessionFactory;
   
   public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	   
	   public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	public KFCHibernateTemplate(){
		
	}	  
	 public KFCHibernateTemplate(SessionFactory sessionFactory){
	     super(sessionFactory);
  }
}