package org.dataFormat;

import java.text.SimpleDateFormat;

public class KFCSimpleDateFormat extends SimpleDateFormat {

	private static final long serialVersionUID = 1L;
	public KFCSimpleDateFormat(){
		super("yyyy-MM-dd");
	}
}
